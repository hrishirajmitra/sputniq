
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn
import time
import math

app = FastAPI(title="Smart Assistant Agent")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class Task(BaseModel):
    prompt: str

@app.post("/api/ask")
async def ask_agent(task: Task):
    prompt = task.prompt.lower()
    time.sleep(1) # simulate thinking
    
    if "calculate" in prompt or "math" in prompt:
        return {"reply": f"Calculating... The secret value implies Pi * 42 is roughly {math.pi * 42:.2f}. Agent logic executed successfully!"}
    if "hello" in prompt:
        return {"reply": "Greetings! I am your newly deployed Smart Assistant running dynamically in my own Sputniq container!"}
        
    return {"reply": f"I pondered over '{task.prompt}' and reached a profound conclusion. I am functioning perfectly."}

def run():
    print("Starting complex API Agent on port 8001...")
    uvicorn.run("agent:app", host="0.0.0.0", port=8001)

if __name__ == '__main__':
    run()
