
import uvicorn
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="TinyLocalLLM Inference Node")

class InferenceRequest(BaseModel):
    text: str

@app.post("/api/inference")
async def generate(req: InferenceRequest):
    print(f"[Model-Node] Running inference on: {req.text}")
    # Simulate a local small model
    t = req.text.lower()
    if 'complex' in t or 'e2e' in t:
        output = "Analyzing e2e complexity... The simulated neural network (2M parameters) concludes this is a highly sophisticated infrastructure."
    elif 'hello' in t:
        output = "Greetings! I am TinyLocalLLM-v1 serving inferences locally without external APIs."
    else:
        output = f"Inferred semantic meaning: Extracting entities from '{req.text}'. Result: Neutral sentiment."
        
    return {"completion": output, "model_id": "tiny-local-llm-v1.0"}

def run():
    print("🧠 Booting Local Model Inference Engine on Port 8003")
    uvicorn.run("model_node:app", host="0.0.0.0", port=8003)

if __name__ == "__main__":
    run()
