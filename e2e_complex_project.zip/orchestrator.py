
import os
import requests
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="E2E Orchestrator Service")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

class RequestData(BaseModel):
    prompt: str

@app.post("/api/orchestrate")
async def run_orchestration(req: RequestData):
    print(f"[Orchestrator] Received prompt '{req.prompt}'. Breaking down tasks...")
    
    steps_taken = [
        "1. Validated and sanitized input context.",
        "2. Checked vector state-store (cache miss).",
        "3. Routing request to dedicated 'model-node' for inference."
    ]
    
    # Query our partner agent (model-node) deployed by Sputniq on port 8003
    try:
        res = requests.post("http://localhost:8003/api/inference", json={"text": req.prompt})
        res.raise_for_status()
        model_result = res.json().get("completion")
        steps_taken.append("4. Received successful inference tensor completion.")
    except Exception as e:
        model_result = f"Failed to reach model-node via HTTP RPC. Error: {str(e)}"
        steps_taken.append("4. FATAL: Local Model API Call Failed.")
        
    return {
        "status": "success",
        "input_prompt": req.prompt,
        "workflow_steps": steps_taken,
        "model_output": model_result
    }

def run():
    print("🚀 Booting Sputniq Orchestrator on Port 8002")
    uvicorn.run("orchestrator:app", host="0.0.0.0", port=8002)

if __name__ == "__main__":
    run()
