
import time
import os

def run():
    print('Starting minimal agent...')
    print('KAFKA_BOOTSTRAP_SERVERS:', os.getenv('KAFKA_BOOTSTRAP_SERVERS'))
    while True:
        print('Agent is running and waiting for messages...')
        time.sleep(5)

if __name__ == '__main__':
    run()
